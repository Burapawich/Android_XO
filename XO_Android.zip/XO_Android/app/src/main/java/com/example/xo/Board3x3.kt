package com.example.xo

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class Board3x3 : AppCompatActivity() {
    private lateinit var btn0: Button
    private lateinit var btn1: Button
    private lateinit var btn2: Button
    private lateinit var btn3: Button
    private lateinit var btn4: Button
    private lateinit var btn5: Button
    private lateinit var btn6: Button
    private lateinit var btn7: Button
    private lateinit var btn8: Button
    private lateinit var textgame: TextView
    private var currentPlayer : String = "X"
    private var arr = Array<Array<String>>(3) {
        Array<String>(3) { "" }
    }
    var checkwin = Wincheck(3)

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_board3x3)

        checkwin.WIN=3
        checkwin.sizemax=3

        btn0 = findViewById(R.id.btn_0)
        btn1 = findViewById(R.id.btn_1)
        btn2 = findViewById(R.id.btn_2)
        btn3 = findViewById(R.id.btn_3)
        btn4 = findViewById(R.id.btn_4)
        btn5 = findViewById(R.id.btn_5)
        btn6 = findViewById(R.id.btn_6)
        btn7 = findViewById(R.id.btn_7)
        btn8 = findViewById(R.id.btn_8)
        textgame = findViewById(R.id.Textgame)

        btn0.setOnClickListener { toggleXO(0) }
        btn1.setOnClickListener { toggleXO(1) }
        btn2.setOnClickListener { toggleXO(2) }
        btn3.setOnClickListener { toggleXO(3) }
        btn4.setOnClickListener { toggleXO(4) }
        btn5.setOnClickListener { toggleXO(5) }
        btn6.setOnClickListener { toggleXO(6) }
        btn7.setOnClickListener { toggleXO(7) }
        btn8.setOnClickListener { toggleXO(8) }
    }

    private fun toggleXO(btn:Int)
    {
        var check = false
        when(btn){
            0-> {
                if(btn0.text == "")
                {
                    btn0.text = currentPlayer
                    check = true
                    arr[0][0]=currentPlayer
                }
            }
            1-> {
                if(btn1.text == "")
                {
                    btn1.text = currentPlayer
                    check = true
                    arr[0][1]=currentPlayer
                }
            }
            2->{
                if(btn2.text == "")
                {
                    btn2.text = currentPlayer
                    check = true
                    arr[0][2]=currentPlayer
                }
            }
            3->{
                if(btn3.text == "")
                {
                    btn3.text = currentPlayer
                    check = true
                    arr[1][0]=currentPlayer
                }
            }
            4->{
                if(btn4.text == "")
                {
                    btn4.text = currentPlayer
                    check = true
                    arr[1][1]=currentPlayer
                }
            }
            5->{
                if(btn5.text == "")
                {
                    btn5.text = currentPlayer
                    check = true
                    arr[1][2]=currentPlayer
                }
            }
            6->{
                if(btn6.text == "")
                {
                    btn6.text = currentPlayer
                    check = true
                    arr[2][0]=currentPlayer
                }
            }
            7->{
                if(btn7.text == "")
                {
                    btn7.text = currentPlayer
                    check = true
                    arr[2][1]=currentPlayer
                }
            }
            8->{
                if(btn8.text == "")
                {
                    btn8.text = currentPlayer
                    check = true
                    arr[2][2]=currentPlayer
                }
            }
        }
        checkwin.arr=arr
        checkwin.player=currentPlayer
        var checkfun=checkwin.check_WIN()
        when(checkfun){
            1->{
                textgame.text = "Player $currentPlayer WIN"
                for(i in 0 until 9){
                    when(i){
                        0-> {
                            if (btn0.text == "") {
                                btn0.text = " "
                            }
                        }
                        1->{
                            if(btn1.text == "")
                            {
                                btn1.text = " "
                            }
                        }
                        2->{
                            if(btn2.text == "")
                            {
                                btn2.text = " "
                            }
                        }
                        3->{
                            if(btn3.text == "")
                            {
                                btn3.text = " "
                            }
                        }
                        4->{
                            if(btn4.text == "")
                            {
                                btn4.text = " "
                            }
                        }
                        5->{
                            if(btn5.text == "")
                            {
                                btn5.text = " "
                            }
                        }
                        6->{
                            if(btn6.text == "")
                            {
                                btn6.text = " "
                            }
                        }
                        7->{
                            if(btn7.text == "")
                            {
                                btn7.text = " "
                            }
                        }
                        8->{
                            if(btn8.text == "")
                            {
                                btn8.text = " "
                            }
                        }
                    }
                }
            }
        2-> textgame.text = "DRAW"
        }

        if(check) {
            if (currentPlayer == "X") {
                currentPlayer = "O"
            } else {
                currentPlayer = "X"
            }
        }
    }
}