package com.example.xo

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class Board5x5 : AppCompatActivity() {
    private lateinit var btn0: Button
    private lateinit var btn1: Button
    private lateinit var btn2: Button
    private lateinit var btn3: Button
    private lateinit var btn4: Button
    private lateinit var btn5: Button
    private lateinit var btn6: Button
    private lateinit var btn7: Button
    private lateinit var btn8: Button
    private lateinit var btn9: Button
    private lateinit var btn10: Button
    private lateinit var btn11: Button
    private lateinit var btn12: Button
    private lateinit var btn13: Button
    private lateinit var btn14: Button
    private lateinit var btn15: Button
    private lateinit var btn16: Button
    private lateinit var btn17: Button
    private lateinit var btn18: Button
    private lateinit var btn19: Button
    private lateinit var btn20: Button
    private lateinit var btn21: Button
    private lateinit var btn22: Button
    private lateinit var btn23: Button
    private lateinit var btn24: Button
    private lateinit var textgame: TextView

    private var currentPlayer : String = "X"
    private var arr = Array<Array<String>>(5) {
        Array<String>(5) { "" }
    }
    var checkwin = Wincheck(5)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_board5x5)

        checkwin.WIN=4
        checkwin.sizemax=5

        btn0 = findViewById(R.id.btn_0)
        btn1 = findViewById(R.id.btn_1)
        btn2 = findViewById(R.id.btn_2)
        btn3 = findViewById(R.id.btn_3)
        btn4 = findViewById(R.id.btn_4)
        btn5 = findViewById(R.id.btn_5)
        btn6 = findViewById(R.id.btn_6)
        btn7 = findViewById(R.id.btn_7)
        btn8 = findViewById(R.id.btn_8)
        btn9 = findViewById(R.id.btn_9)
        btn10 = findViewById(R.id.btn_10)
        btn11 = findViewById(R.id.btn_11)
        btn12 = findViewById(R.id.btn_12)
        btn13 = findViewById(R.id.btn_13)
        btn14 = findViewById(R.id.btn_14)
        btn15 = findViewById(R.id.btn_15)
        btn16 = findViewById(R.id.btn_16)
        btn17 = findViewById(R.id.btn_17)
        btn18 = findViewById(R.id.btn_18)
        btn19 = findViewById(R.id.btn_19)
        btn20 = findViewById(R.id.btn_20)
        btn21 = findViewById(R.id.btn_21)
        btn22 = findViewById(R.id.btn_22)
        btn23 = findViewById(R.id.btn_23)
        btn24 = findViewById(R.id.btn_24)
        textgame = findViewById(R.id.Textgame)

        btn0.setOnClickListener { toggleXO(0) }
        btn1.setOnClickListener { toggleXO(1) }
        btn2.setOnClickListener { toggleXO(2) }
        btn3.setOnClickListener { toggleXO(3) }
        btn4.setOnClickListener { toggleXO(4) }
        btn5.setOnClickListener { toggleXO(5) }
        btn6.setOnClickListener { toggleXO(6) }
        btn7.setOnClickListener { toggleXO(7) }
        btn8.setOnClickListener { toggleXO(8) }
        btn9.setOnClickListener { toggleXO(9) }
        btn10.setOnClickListener { toggleXO(10) }
        btn11.setOnClickListener { toggleXO(11) }
        btn12.setOnClickListener { toggleXO(12) }
        btn13.setOnClickListener { toggleXO(13) }
        btn14.setOnClickListener { toggleXO(14) }
        btn15.setOnClickListener { toggleXO(15) }
        btn16.setOnClickListener { toggleXO(16) }
        btn17.setOnClickListener { toggleXO(17) }
        btn18.setOnClickListener { toggleXO(18) }
        btn19.setOnClickListener { toggleXO(19) }
        btn20.setOnClickListener { toggleXO(20) }
        btn21.setOnClickListener { toggleXO(21) }
        btn22.setOnClickListener { toggleXO(22) }
        btn23.setOnClickListener { toggleXO(23) }
        btn24.setOnClickListener { toggleXO(24) }
    }

    private fun toggleXO(btn:Int)
    {
        var check = false
        when(btn){
            0-> {
                if(btn0.text == "")
                {
                    btn0.text = currentPlayer
                    check = true
                    arr[0][0]=currentPlayer
                }
            }
            1-> {
                if(btn1.text == "")
                {
                    btn1.text = currentPlayer
                    check = true
                    arr[0][1]=currentPlayer
                }
            }
            2->{
                if(btn2.text == "")
                {
                    btn2.text = currentPlayer
                    check = true
                    arr[0][2]=currentPlayer
                }
            }
            3->{
                if(btn3.text == "")
                {
                    btn3.text = currentPlayer
                    check = true
                    arr[0][3]=currentPlayer
                }
            }
            4->{
                if(btn4.text == "")
                {
                    btn4.text = currentPlayer
                    check = true
                    arr[0][4]=currentPlayer
                }
            }
            5->{
                if(btn5.text == "")
                {
                    btn5.text = currentPlayer
                    check = true
                    arr[1][0]=currentPlayer
                }
            }
            6->{
                if(btn6.text == "")
                {
                    btn6.text = currentPlayer
                    check = true
                    arr[1][1]=currentPlayer
                }
            }
            7->{
                if(btn7.text == "")
                {
                    btn7.text = currentPlayer
                    check = true
                    arr[1][2]=currentPlayer
                }
            }
            8->{
                if(btn8.text == "")
                {
                    btn8.text = currentPlayer
                    check = true
                    arr[1][3]=currentPlayer
                }
            }
            9->{
                if(btn9.text == "")
                {
                    btn9.text = currentPlayer
                    check = true
                    arr[1][4]=currentPlayer
                }
            }
            10->{
                if(btn10.text == "")
                {
                    btn10.text = currentPlayer
                    check = true
                    arr[2][0]=currentPlayer
                }
            }
            11->{
                if(btn11.text == "")
                {
                    btn11.text = currentPlayer
                    check = true
                    arr[2][1]=currentPlayer
                }
            }
            12->{
                if(btn12.text == "")
                {
                    btn12.text = currentPlayer
                    check = true
                    arr[2][2]=currentPlayer
                }
            }
            13->{
                if(btn13.text == "")
                {
                    btn13.text = currentPlayer
                    check = true
                    arr[2][3]=currentPlayer
                }
            }
            14->{
                if(btn14.text == "")
                {
                    btn14.text = currentPlayer
                    check = true
                    arr[2][4]=currentPlayer
                }
            }
            15->{
                if(btn15.text == "")
                {
                    btn15.text = currentPlayer
                    check = true
                    arr[3][0]=currentPlayer
                }
            }
            16->{
                if(btn16.text == "")
                {
                    btn16.text = currentPlayer
                    check = true
                    arr[3][1]=currentPlayer
                }
            }
            17->{
                if(btn17.text == "")
                {
                    btn17.text = currentPlayer
                    check = true
                    arr[3][2]=currentPlayer
                }
            }
            18->{
                if(btn18.text == "")
                {
                    btn18.text = currentPlayer
                    check = true
                    arr[3][3]=currentPlayer
                }
            }
            19->{
                if(btn19.text == "")
                {
                    btn19.text = currentPlayer
                    check = true
                    arr[3][4]=currentPlayer
                }
            }
            20->{
                if(btn20.text == "")
                {
                    btn20.text = currentPlayer
                    check = true
                    arr[4][0]=currentPlayer
                }
            }
            21->{
                if(btn21.text == "")
                {
                    btn21.text = currentPlayer
                    check = true
                    arr[4][1]=currentPlayer
                }
            }
            22->{
                if(btn22.text == "")
                {
                    btn22.text = currentPlayer
                    check = true
                    arr[4][2]=currentPlayer
                }
            }
            23->{
                if(btn23.text == "")
                {
                    btn23.text = currentPlayer
                    check = true
                    arr[4][3]=currentPlayer
                }
            }
            24->{
                if(btn24.text == "")
                {
                    btn24.text = currentPlayer
                    check = true
                    arr[4][4]=currentPlayer
                }
            }
        }
        checkwin.arr=arr
        checkwin.player=currentPlayer
        var checkfun=checkwin.check_WIN()

        when(checkfun){
            1->{
                textgame.text = "Player $currentPlayer WIN"
                for(i in 0 until 9){
                    when(i){
                        0-> {
                            if (btn0.text == "") {
                                btn0.text = " "
                            }
                        }
                        1->{
                            if(btn1.text == "")
                            {
                                btn1.text = " "
                            }
                        }
                        2->{
                            if(btn2.text == "")
                            {
                                btn2.text = " "
                            }
                        }
                        3->{
                            if(btn3.text == "")
                            {
                                btn3.text = " "
                            }
                        }
                        4->{
                            if(btn4.text == "")
                            {
                                btn4.text = " "
                            }
                        }
                        5->{
                            if(btn5.text == "")
                            {
                                btn5.text = " "
                            }
                        }
                        6->{
                            if(btn6.text == "")
                            {
                                btn6.text = " "
                            }
                        }
                        7->{
                            if(btn7.text == "")
                            {
                                btn7.text = " "
                            }
                        }
                        8->{
                            if(btn8.text == "")
                            {
                                btn8.text = " "
                            }
                        }
                        9->{
                            if(btn9.text == "")
                            {
                                btn9.text = " "
                            }
                        }
                        10->{
                            if(btn10.text == "")
                            {
                                btn10.text = " "
                            }
                        }
                        11->{
                            if(btn11.text == "")
                            {
                                btn11.text = " "
                            }
                        }
                        12->{
                            if(btn12.text == "")
                            {
                                btn12.text = " "
                            }
                        }
                        13->{
                            if(btn13.text == "")
                            {
                                btn13.text = " "
                            }
                        }
                        14->{
                            if(btn14.text == "")
                            {
                                btn14.text = " "
                            }
                        }
                        15->{
                            if(btn15.text == "")
                            {
                                btn15.text = " "
                            }
                        }
                        16->{
                            if(btn16.text == "")
                            {
                                btn16.text = " "
                            }
                        }
                        17->{
                            if(btn17.text == "")
                            {
                                btn17.text = " "
                            }
                        }
                        18->{
                            if(btn18.text == "")
                            {
                                btn18.text = " "
                            }
                        }
                        19->{
                            if(btn19.text == "")
                            {
                                btn19.text = " "
                            }
                        }
                        20->{
                            if(btn20.text == "")
                            {
                                btn20.text = " "
                            }
                        }
                        21->{
                            if(btn21.text == "")
                            {
                                btn21.text = " "
                            }
                        }
                        22->{
                            if(btn22.text == "")
                            {
                                btn22.text = " "
                            }
                        }
                        23->{
                            if(btn23.text == "")
                            {
                                btn23.text = " "
                            }
                        }
                        24->{
                            if(btn24.text == "")
                            {
                                btn24.text = " "
                            }
                        }
                    }
                }
            }
            2-> textgame.text = "DRAW"
        }

        if(check) {
            if (currentPlayer == "X") {
                currentPlayer = "O"
            } else {
                currentPlayer = "X"
            }
        }
    }
}