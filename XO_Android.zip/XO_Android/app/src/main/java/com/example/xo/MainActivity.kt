package com.example.xo

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var btnstart: Button
    private lateinit var size: Spinner
    private var boardsize = arrayOf("3x3","4x4","5x5")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        size = findViewById(R.id.SizeSpinner)
        btnstart = findViewById(R.id.BtnStart)

        val arrayadp = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, boardsize)
        size.adapter = arrayadp
        size?.onItemSelectedListener = object : AdapterView.OnItemSelectedListener
        {
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long)
            {
                if(p2==0)
                {
                    //Toast.makeText(this@MainActivity, p2.toString(), Toast.LENGTH_SHORT).show()
                    btnstart.setOnClickListener { createBoard3x3() }
                }
                else if(p2==1)
                {
                    //Toast.makeText(this@MainActivity, p2.toString(), Toast.LENGTH_SHORT).show()
                    btnstart.setOnClickListener { createBoard4x4() }
                }
                else if(p2==2)
                {
                    //Toast.makeText(this@MainActivity, p2.toString(), Toast.LENGTH_SHORT).show()
                    btnstart.setOnClickListener { createBoard5x5() }
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?)
            {
                Toast.makeText(this@MainActivity, "Nothing Selected", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun createBoard3x3() {
        val intent = Intent(this,Board3x3::class.java)
        startActivity(intent)
    }

    private fun createBoard4x4() {
        val intent = Intent(this,Board4x4::class.java)
        startActivity(intent)
    }

    private fun createBoard5x5() {
        val intent = Intent(this,Board5x5::class.java)
        startActivity(intent)
    }
}