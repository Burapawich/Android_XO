package com.example.xo

class Wincheck(arrsize:Int) {
    var arr = Array<Array<String>>(arrsize) {Array<String> (arrsize){ "" } }
    var sizemax: Int = 0
    var player: String = ""
    var WIN: Int = 0

    fun check_WIN(): Int {
        if (check_row() || check_col() || check_diagonalL() || check_diagonalR()) {
            return 1
        } else if (check_draw()) {
            return 2
        }
        return 0
    }

    fun check_row(): Boolean {
        var count: Int = 0
        var i: Int
        var j: Int
        var rnt: Boolean = false
        for (i in 0 until sizemax) {
            count = 0
            for (j in 0 until sizemax) {
                if (arr[i][j] == player) {
                    count++
                    if (count == WIN) {
                        rnt = true
                    }
                } else {
                    count = 0
                }
            }
        }
        return rnt
    }

    fun check_col(): Boolean {
        var count: Int = 0
        var i: Int
        var j: Int
        var rnt: Boolean = false
        for (j in 0 until sizemax) {
            count = 0
            for (i in 0 until sizemax) {
                if (arr[i][j] == player) {
                    count++
                    if (count == WIN) {
                        rnt = true
                    }
                } else {
                    count = 0
                }
            }
        }
        return rnt
    }

    fun check_diagonalL(): Boolean {
        var count: Int = 0
        var i: Int
        var j: Int
        var b: Int
        var c: Int
        var rnt: Boolean = false
        for (b in 0 until sizemax) {
            for (c in 0 until sizemax) {
                j = c
                i = b
                count = 0
                while (i < sizemax && j < sizemax) {
                    if (arr[i][j] == player) {
                        count++
                        if (count == WIN) {
                            rnt = true
                        }
                    } else {
                        count = 0
                    }
                    j++
                    i++
                }
            }
        }
        return rnt
    }

    fun check_diagonalR(): Boolean {
        var count: Int = 0
        var i: Int
        var j: Int
        var b: Int
        var c: Int
        var rnt: Boolean = false
        for (b in 0 until sizemax) {
            for (c in 0 until sizemax) {
                var j = sizemax - 1 - c
                var i = b
                count = 0
                while ((i < sizemax) && (j >= 0)) {
                    if (arr[i][j] == player) {
                        count++
                        if (count == WIN) {
                            rnt = true
                        }
                    } else {
                        count = 0
                    }
                    j--
                    i++
                }
            }
        }
        return rnt
    }

    fun check_draw(): Boolean {
        var count: Int = 0
        var i: Int
        var j: Int
        var size: Int
        var rnt: Boolean = false
        size = sizemax * sizemax
        for (i in 0 until sizemax) {
            for (j in 0 until sizemax) {
                if (arr[i][j] != "") {
                    count++
                    if (count == size) {
                        rnt = true
                    }
                }
            }
        }
        return rnt
    }
}
